package utils;

import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.Service;
import org.hibernate.service.ServiceRegistry;

public class HibernetUtil 
{

	private static SessionFactory sf;
	
		static
		{
			System.out.println("IN STATIC METHOD");
			try
			{
			StandardServiceRegistry reg=new
								StandardServiceRegistryBuilder().configure().build();
			sf=new MetadataSources(reg).buildMetadata().buildSessionFactory();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	public static SessionFactory getsf()
	{
		return sf;
	}
}
