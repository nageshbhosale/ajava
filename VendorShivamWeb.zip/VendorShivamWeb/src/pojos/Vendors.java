package pojos;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;

@Entity
@Table(name="vendor")
public class Vendors 
{
	private Integer id;
	private String name,email,city;
	private Integer contact;
	
	private List<Account> acc = new ArrayList<>();
	
	
	//Constructors
	
	public Vendors() {
		// TODO Auto-generated constructor stub
		System.out.println("In constructor of vendor");
	}


	public Vendors(Integer id, String name, String email, String city, Integer contact) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.city = city;
		this.contact = contact;
	}


	public Vendors(String name, String email, String city, Integer contact) {
		super();
		this.name = name;
		this.email = email;
		this.city = city;
		this.contact = contact;
	}

	//Getter Setter Methods

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}

@Column(name="name")
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}

@Column(name="email",unique=true)
	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name="city")
	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}

	@Column(name="contact")
	public Integer getContact() {
		return contact;
	}


	public void setContact(Integer contact) {
		this.contact = contact;
	}
	
	@OneToMany(mappedBy="myVen",fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	public List<Account> getAcc() {
		return acc;
	}


	public void setAcc(List<Account> acc) {
		this.acc = acc;
	}

	//to string Methods

	@Override
	public String toString() {
		return "Vendors [id=" + id + ", name=" + name + ", email=" + email + ", city=" + city + ", contact=" + contact
				+ "]";
	}
	
	//Convience Methods
	
	public void addAccount(Account accs){
		
		acc.add(accs);
		accs.setMyVen(this);		
	}
	
	public void removeAccount(Account s)
	{
		acc.remove(s);
		s.setMyVen(null);
	}
}
