package pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="account")
public class Account {
	
	private Integer bid;
	private String acctype;
	private double balance;
	
	private Vendors myVen;
	
	//Constructors
	
	public Account() {
		// TODO Auto-generated constructor stub
	}

	public Account(Integer bid, String acctype, double balance) {
		super();
		this.bid = bid;
		this.acctype = acctype;
		this.balance = balance;
	}

	public Account(String acctype, double balance) {
		super();
		this.acctype = acctype;
		this.balance = balance;
	}
	
	//Getter Setter Methods

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public Integer getBid() {
		return bid;
	}

	public void setBid(Integer bid) {
		this.bid = bid;
	}
@Column(name="acctype")
	public String getAcctype() {
		return acctype;
	}

	public void setAcctype(String acctype) {
		this.acctype = acctype;
	}
	
	@Column(name="balance")
	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
		
	@ManyToOne
	@JoinColumn(name="venid")
	public Vendors getMyVen() {
		return myVen;
	}

	public void setMyVen(Vendors myVen) {
		this.myVen = myVen;
	}
	
	//To String

	@Override
	public String toString() {
		return "Account [bid=" + bid + ", acctype=" + acctype + ", balance=" + balance + "]";
	}
	
	

}
