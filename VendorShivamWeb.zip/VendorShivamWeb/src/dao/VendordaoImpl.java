package dao;

import static utils.HibernetUtil.getsf;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Account;
import pojos.Vendors;

public class VendordaoImpl implements VendorDao
{

	@Override
	public List<Vendors> showvendors() 
	{
		List<Vendors> l1=null;

		String jpql="select v from Vendors v";
		Session hs=getsf().openSession();
		Transaction tx=hs.beginTransaction();
		try
		{
			l1=hs.createQuery(jpql, Vendors.class).getResultList();
		}
		catch(Exception e)
		{
			if(tx!=null)
				tx.rollback();
			e.printStackTrace();
		}
		finally
		{
			if(hs!=null)
				hs.close();
		}
		return l1;
	}

	@Override
	public List<Account> showAccount(Integer id) {

		List<Account> l1=null;
		//String jpql="select v from Vendors v";
		System.out.println("IN INSERT FUNCTION");
		Session hs=getsf().openSession();
		Transaction tx=hs.beginTransaction();
		try
		{
			Vendors v=hs.get(Vendors.class,id);
			l1=v.getAcc();
			tx.commit();
		}
		catch (Exception e) 
		{
			if(tx!=null)
			{
				tx.rollback();
			}
			throw e;

		}
		finally 
		{
			if(hs!=null)
			{
				hs.close();
			}
		}

		return l1;
	}
	public int deleteVendor(Integer id) {

		System.out.println("IN Delete FUNCTION");
		Session hs=getsf().openSession();
		Transaction tx=hs.beginTransaction();

		try
		{
			Vendors v=hs.get(Vendors.class, id);
			hs.delete(v);
			tx.commit();
		}
		catch (Exception e) 
		{
			if(tx!=null)
			{
				tx.rollback();
			}
			throw e;

		}
		finally 
		{
			if(hs!=null)
			{
				hs.close();
			}
		}		
		return 0;

	}
	@Override
	public int addAccount(Integer id, Account a) {

		System.out.println("IN INSERT FUNCTION");
		Session hs=getsf().openSession();
		Transaction tx=hs.beginTransaction();
		try
		{
			Vendors v= hs.get(Vendors.class,id);
			v.addAccount(a);
			hs.update(v);
			tx.commit();
		}
		catch (Exception e) 
		{
			if(tx!=null)
			{
				tx.rollback();
			}
			throw e;

		}
		finally 
		{
			if(hs!=null)
			{
				hs.close();
			}
		}

		return 0;
	}

	@Override
	public String UpdateVendor(Integer id, String city, Integer contact) {
		System.out.println("IN INSERT FUNCTION");
		Session hs=getsf().openSession();
		Transaction tx=hs.beginTransaction();
		try
		{
			Vendors v= hs.get(Vendors.class,id);
			if(v!=null)
			{
				v.setCity(city);
				v.setContact(contact);
			}
			tx.commit();

		}
		catch (Exception e) 
		{
			if(tx!=null)
			{
				tx.rollback();
			}
			throw e;

		}
		finally 
		{
			if(hs!=null)
			{
				hs.close();
			}
		}
		return null;
	}
	public int insertVendor(Vendors v) {
		Integer id;
		System.out.println("IN INSERT FUNCTION");
		Session hs=getsf().openSession();
		Transaction tx=hs.beginTransaction();
		try
		{
			hs.save(v);			 
			tx.commit();
		}
		catch (Exception e) 
		{
			if(tx!=null)
			{
				tx.rollback();
			}
			throw e;

		}
		finally 
		{
			if(hs!=null)
			{
				hs.close();
			}
		}

		return 0;
	}

	@Override
	public void deleteAcconly(Integer id, Integer bid)
	{

		System.out.println("IN INSERT FUNCTION");
		Session hs=getsf().openSession();
		Transaction tx=hs.beginTransaction();
		try
		{
			Vendors v=hs.get(Vendors.class,id);
			v.removeAccount(hs.get(Account.class,bid));
			tx.commit();
		}
		catch (Exception e) 
		{
			if(tx!=null)
			{
				tx.rollback();
			}
			throw e;

		}
		finally 
		{
			if(hs!=null)
			{
				hs.close();
			}
		}
	}

	@Override
	public void updateAccType(Integer id, Integer bid, String acctype, double balance) {
	
		Session hs=getsf().openSession();
		Transaction tx=hs.beginTransaction();
		try
		{
	//		Vendors v=hs.get(Vendors.class,id);
			Account a=hs.get(Account.class,bid);
					 a.setAcctype(acctype);
					 a.setBalance(balance);
					hs.update(a);
			tx.commit();
		}
		catch (Exception e) 
		{
			if(tx!=null)
			{
				tx.rollback();
			}
			throw e;
			
		}
		finally 
		{
			if(hs!=null)
			{
				hs.close();
			}
		}
		

	}
	
}
