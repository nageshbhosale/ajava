package dao;

import java.util.List;

import pojos.Account;
import pojos.Vendors;

public interface VendorDao
{
	public List<Vendors> showvendors();
	public List<Account> showAccount(Integer id);
	public int deleteVendor(Integer id);
	public int addAccount(Integer id,Account a);
	public String UpdateVendor(Integer id,String city,Integer contact);
	public int insertVendor(Vendors v);
	public void deleteAcconly(Integer id,Integer bid);
	public void updateAccType(Integer id,Integer bid,String acctype,double balance);
}
