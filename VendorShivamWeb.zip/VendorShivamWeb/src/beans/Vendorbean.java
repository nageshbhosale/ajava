package beans;

import java.util.List;

import dao.VendordaoImpl;
import pojos.Account;
import pojos.Vendors;



public class Vendorbean
{
	private Integer id,contact,bid;
	private String name,email,city,msg,type,acctype;
	private double balance;
	
	
	
	public Integer getBid() {
		return bid;
	}

	public void setBid(Integer bid) {
		this.bid = bid;
	}

	public String getAcctype() {
		return acctype;
	}

	public void setAcctype(String acctype) {
		this.acctype = acctype;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}



	VendordaoImpl dao=null;
	
	//Constructors
	public Vendorbean() {
	
		dao=new VendordaoImpl();
		
	}
	
	public List<Vendors>  getlist() 
	{
		return dao.showvendors();
	}

	//Getters Setters

	public Integer getId() {
		return id;
	}



	public void setId(Integer id) {
		this.id = id;
	}



	public Integer getContact() {
		return contact;
	}



	public void setContact(Integer contact) {
		this.contact = contact;
	}

	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}
	
	public VendordaoImpl getDao() {
		return dao;
	}

	public void setDao(VendordaoImpl dao) {
		this.dao = dao;
	}
	
	public List<Account> getAccount(){
		return dao.showAccount(id);
	}	
	public void DeleteVendor()
	{
		 dao.deleteVendor(id);
	}
	public void AddAcc()
	{
		Account a=new Account(acctype,balance);
		dao.addAccount(id, a);
	}
	public void UpdateVendor()
	{
		dao.UpdateVendor(id,city,contact);
	}
	public void Insertvendor()
	{
		Vendors v=new Vendors(name,email,city,contact);
		dao.insertVendor(v);
	}
	public void DeleteAccount()
	{
		dao.deleteAcconly(id,bid);
	}
	public void updateAccType()
	{
		dao.updateAccType(id,bid,acctype,balance);
	}
}
