package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Book;

@Repository
public class BookDaoImpl implements IBookDao 
{
	@Autowired
	private SessionFactory sf;


	@Override
	public List<Book> getList() {
		// TODO Auto-generated method stub
		String jpql="select b from Book b";
		return sf.getCurrentSession().createQuery(jpql,Book.class).getResultList();
	}

	@Override
	public String addBook(Book b) {
		sf.getCurrentSession().persist(b);
		return "Added";
	}

	@Override
	public Book getDetails(int id) {
		
		return sf.getCurrentSession().get(Book.class, id);
	}

	@Override
	public String updateBook(Book b) {
		sf.getCurrentSession().update(b);
		return "updated";
	}

	@Override
	public String deleteBookDetails(int id) {
		// TODO Auto-generated method stub
		System.out.println("in delete dao");
		System.out.println(id);
		Book b=sf.getCurrentSession().get( Book.class,id);
		sf.getCurrentSession().delete(b);
				return "deleted";
	}
}
