package com.app.dao;

import java.util.List;

import com.app.pojos.Book;

public interface IBookDao 
{
	public String addBook(Book b);
	public List<Book> getList() ;
	public Book getDetails(int id);
    String updateBook(Book b) ;
	String deleteBookDetails(int id); 
}
