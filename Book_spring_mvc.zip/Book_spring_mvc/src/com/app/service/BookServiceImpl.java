package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IBookDao;
import com.app.pojos.Book;
@Service
@Transactional
public class BookServiceImpl implements IBookService
{
   @Autowired
   private IBookDao dao;
   
	@Override
	public String addBook(Book b) {
		// TODO Auto-generated method stub
		return dao.addBook(b);
	}

	@Override
	public List<Book> getList() {
		// TODO Auto-generated method stub
		return dao.getList();
	}

	@Override
	public Book getDetails(int id)
	{
		// TODO Auto-generated method stub
		return dao.getDetails(id);
	}

	@Override
	public String updateBook(Book b) {
		// TODO Auto-generated method stub
		return dao.updateBook(b);
	}

	@Override
	public String deleteBookDetails(int id) {
		System.out.println("in service delete");
		System.out.println(id);
		// TODO Auto-generated method stub
		return dao.deleteBookDetails(id);
	}

}
