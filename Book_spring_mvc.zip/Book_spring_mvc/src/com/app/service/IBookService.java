package com.app.service;

import java.util.List;

import com.app.pojos.Book;

public interface IBookService {
	public String addBook(Book b);
	public List<Book> getList();
    Book getDetails(int id);
    String updateBook(Book b);
    String deleteBookDetails(int id); 

}
