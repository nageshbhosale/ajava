package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Book;
import com.app.service.IBookService;

@Controller
@RequestMapping("/book")
public class BookController 
{
	@Autowired
	private IBookService service;
	
	@GetMapping("/add")
	public String show(Book b)
	{
		System.out.println("in show book add");
		System.out.println(b);
		System.out.println("in show");
		return "/book/add";
	}

	@PostMapping("/add")
	public String addBook(Book b,RedirectAttributes flashMap)
	{
		System.out.println("in show book post add");
		System.out.println(b);
		//Book b=new Book(title,author,category,quantity,price);
		flashMap.addFlashAttribute("book",service.addBook(b));
		return "redirect:/book/list";
	}

	@GetMapping("/list")
	public String GetList(Model Map)
	{
		System.out.println("in show");
		List<Book>l= service.getList();
		System.out.println("in list"+l);
		Map.addAttribute("book_show",l);
		return "/book/list";
	}
	
	@GetMapping("/update")
	public String getBook(Model map,@RequestParam int id)
	{
		
		map.addAttribute("book_update",service.getDetails(id));
		return "/book/update";    	
	}

	@PostMapping("/update")
	public String updateBook(Book b)
	{
		System.out.println("in update");
		System.out.println(b);
		service.updateBook(b);
		return "redirect:/book/list";    	
	}
	@GetMapping("/delete")
	public String deleteBookDetails(@RequestParam int id,RedirectAttributes flashMap)
	{
		System.out.println("in delete book");
		System.out.println(id);
		flashMap.addFlashAttribute("status",service.deleteBookDetails(id));
		return "redirect:/book/list";
		
	}
	
	
}
